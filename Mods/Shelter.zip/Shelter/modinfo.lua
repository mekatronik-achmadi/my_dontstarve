name = "Shelter"
description = "Another island masterpiece!"
author = "Afro1967"
version = "1.0"

forumthread = ""

api_version = 6

dont_starve_compatible = true
reign_of_giants_compatible = true

icon_atlas = "siesta_shelter.xml"
icon = "siesta_shelter.tex"
